create
    definer = root@localhost procedure statistic_mark(IN CourseName char(30))
begin
    declare less60 int default 0;
    declare b60a70 int default 0;
    declare b70a80 int default 0;
    declare b80a90  int default 0;
    declare more90 int default 0;
    declare currCno CHAR(4);
    select `Cno` into currCno from `course` where `Cname`=CourseName;
    select count(*) into less60 from `sc` where `Cno` =currCno and `Grade`<60;
    select count(*) into b60a70 from `sc` where `Cno` =currCno and `Grade`>=60 and `Grade`<70;
    select count(*) into b70a80 from `sc` where `Cno` =currCno and `Grade`>=70 and `Grade`<80;
    select count(*) into b80a90 from `sc` where `Cno` =currCno and `Grade`>=80 and `Grade`<90;
    select count(*) into more90 from `sc` where `Cno` =currCno and `Grade`>=90 ;
    insert into `rank`(`division`,`number`) values ('[0,60)',less60);
    insert into `rank`(`division`,`number`) values ('[60,70)',b60a70);
    insert into `rank`(`division`,`number`) values ('[70,80)',b70a80);
    insert into `rank`(`division`,`number`) values ('[80,90)',b80a90);
    insert into `rank`(`division`,`number`) values ('[90,100)',more90);
end;

